---
avatar: avatar.png
degree: PhD
email: nethermanpro@sjtu.edu.cn
enroll_date: ''
fields: ST
join_date: '2023-09-01'
name: 乐辰阳
role: student
---
