---
avatar: avatar.png
degree: Master
email: fayuge@sjtu.edu.cn
enroll_date: '2022.9'
fields: RAA
join_date: 2021-6-27
name: Haoyu Wang
role: student
---
