---
avatar: avatar.png
degree: PhD
email: hanbing97@sjtu.edu.cn
enroll_date: '2020-09-01'
fields:
- SID
- TTS
join_date: '2020-09-01'
name: 韩冰
role: student
---
主要进行说话人验证，音频合成等方向的研究。