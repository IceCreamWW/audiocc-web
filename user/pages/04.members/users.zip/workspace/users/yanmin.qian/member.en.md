---
avatar: avatar.png
degree: ''
email: yanminqian@sjtu.edu.cn
enroll_date: unknown
fields: []
join_date: unknown
name: Yanmin Qian
role: student
---
