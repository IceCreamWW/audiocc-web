---
avatar: avatar.png
degree: Master
email: zxzx818@sjtu.edu.cn
enroll_date: '2023-09-08'
fields: SE
join_date: '2023-07-04'
name: 周鑫
role: student
---
