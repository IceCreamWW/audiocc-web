---
avatar: avatar.png
degree: Master
email: hangshao99@sjtu.edu.cn
enroll_date: '2021-09-01'
fields: ASR
join_date: '2021-09-01'
name: Hang Shao
role: student
---
