---
avatar: avatar.png
degree: Undergraduate
email: 995999277@sjtu.edu.cn
enroll_date: ''
fields: ASR
join_date: '2023-03-07'
name: Tianteng Gu
role: student
---
