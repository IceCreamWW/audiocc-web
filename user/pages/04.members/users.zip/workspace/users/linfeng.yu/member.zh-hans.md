---
avatar: avatar.png
degree: Master
email: ylf2017@sjtu.edu.cn
enroll_date: ''
fields: SE
join_date: '2021-09-01'
name: 余林峰
role: student
---
