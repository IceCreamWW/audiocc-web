---
avatar: avatar.png
degree: PhD
email: wangwei.sjtu@sjtu.edu.cn
enroll_date: '2021-09-01'
fields: ASR
join_date: '2018-11-01'
name: Wei Wang
role: student
---
