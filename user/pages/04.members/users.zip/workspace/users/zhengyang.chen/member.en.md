---
avatar: avatar.png
degree: PhD
email: zhengyang.chen@sjtu.edu.cn
enroll_date: ''
fields: SID
join_date: '2019-09-06'
name: Zhengyang Chen
role: student
---
