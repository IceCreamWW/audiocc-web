---
avatar: avatar.png
degree: PhD
email: gongxun@sjtu.edu.cn
enroll_date: '2021-09-10'
fields:
- ASR
- SE
join_date: '2019-07-01'
name: Xun Gong
role: student
---
研究大规模语音识别以及其自适应相关内容