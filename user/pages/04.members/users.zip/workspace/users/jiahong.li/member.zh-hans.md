---
avatar: avatar.png
degree: Master
email: li_jiahong@sjtu.edu.cn
enroll_date: ''
fields: ASR
join_date: '2022-09-01'
name: 李嘉鸿
role: student
---
