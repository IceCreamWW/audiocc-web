---
avatar: avatar.png
degree: Undergraduate
email: 123hh3298@sjtu.edu.cn
enroll_date: ''
fields: SID
join_date: '2023-11-23'
name: 张瑛鹏
role: student
---
