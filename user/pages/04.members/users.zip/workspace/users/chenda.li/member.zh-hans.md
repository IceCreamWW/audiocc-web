---
avatar: avatar.png
degree: PhD
email: lichenda1996@sjtu.edu.cn
enroll_date: ''
fields: SE
join_date: '2018-09-01'
name: 李晨达
role: student
---
