---
avatar: avatar.png
degree: Master
email: zsy_coding@sjtu.edu.cn
enroll_date: ''
fields: ASR
join_date: '2019-10-30'
name: 赵思怡
role: student
---
