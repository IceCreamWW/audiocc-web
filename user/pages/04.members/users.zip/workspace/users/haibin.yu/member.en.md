---
avatar: avatar.png
degree: PhD
email: yuhaibin_39@sjtu.edu.cn
enroll_date: '2022-09-01'
fields: SS
join_date: '2022-09-01'
name: Haibin Yu
role: student
---
