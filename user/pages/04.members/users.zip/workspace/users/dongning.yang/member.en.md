---
avatar: avatar.png
degree: Undergraduate
email: ydn_1007@sjtu.edu.cn
enroll_date: ''
fields: ASR
join_date: '2022-06-02'
name: Dongning Yang
role: student
---
