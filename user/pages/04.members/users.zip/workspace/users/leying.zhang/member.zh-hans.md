---
avatar: avatar.png
degree: PhD
email: zhangleying@sjtu.edu.cn
enroll_date: '2021-09-01'
fields: TTS
join_date: '2020-09-01'
name: 张乐莹
role: student
---
