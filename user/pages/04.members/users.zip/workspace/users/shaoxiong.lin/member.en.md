---
avatar: avatar.png
degree: Master
email: Johnson-Lin@sjtu.edu.cn
enroll_date: ''
fields: SE
join_date: '2019-11-08'
name: Shaoxiong Lin
role: student
---
