---
avatar: avatar.png
degree: Undergraduate
email: houhaoxiang0701@sjtu.edu.cn
enroll_date: ''
fields: ASR
join_date: 2023-8-1
name: Haoxiang Hou
role: student
---
