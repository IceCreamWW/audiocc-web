---
avatar: avatar.png
degree: Master
email: holvan@sjtu.edu.cn
enroll_date: '2023-09-08'
fields: RAA
join_date: '2022-05-07'
name: Wen Huang
role: student
---
