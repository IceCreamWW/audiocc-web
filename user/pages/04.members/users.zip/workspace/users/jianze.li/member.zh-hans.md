---
avatar: avatar.png
degree: Undergraduate
email: mon3tr@sjtu.edu.cn
enroll_date: ''
fields: RAA
join_date: 2022-1-1
name: 李建泽
role: student
---
