---
avatar: avatar.png
degree: Undergraduate
email: stupid_computer@sjtu.edu.cn
enroll_date: ''
fields: Audio Generation
join_date: 2023-8-10
name: 周庭孝
role: student
---
