---
avatar: avatar.png
degree: PhD
email: wyz-97@sjtu.edu.cn
enroll_date: '2018-09-01'
fields: ASR
join_date: '2018-09-01'
name: 张王优
role: student
---
